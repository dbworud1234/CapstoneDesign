function logout() {
  Kakao.init("e965922752dd0e459d202be15719070e");
  if(confirm("로그아웃을 하시겠습니까? ") == true){
    Kakao.Auth.logout(function(data){
      if(data == true){
        alert("초기화면으로 이동합니다.");
        window.location = "/logout";
      } else {
        alert("fail");
      }
    });
  };
};
