Kakao.init('e965922752dd0e459d202be15719070e');
function loginF(){
  Kakao.Auth.loginForm({
    success: function(authObj) {
      Kakao.API.request({
        url: '/v2/user/me',
        success: function(res){
          window.location = "/users";
          // location.href = "/main";
        },
        fail: function(error){
          alert(JSON.stringify(error));
        }
      });
    },
    fail: function(err) {
      alert(JSON.stringify(err));
    }
  });
}
window.sessionStorage.setItem('name', name);
let dataName = sessionStorage.getItem('name');
