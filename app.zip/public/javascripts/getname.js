var kakao_get_name = function() {
  Kakao.init("e965922752dd0e459d202be15719070e");
  Kakao.API.request({
    url: '/v2/user/me',
    success: function(res){
      name = res.properties.nickname;
      return name;
    },
    fail: function(error){
      alert(JSON.stringify(error));
    }
  });
};
