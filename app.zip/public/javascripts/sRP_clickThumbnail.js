function onclickImg(index){
  player.loadVideoById(confirmedData[index].VID);
  document.getElementById("btn-img").src="/images/pause.png"; a=0;
}
