module.exports = (sequelize, DataTypes) => {
  return sequelize.define('board', {
    number : {
      type : DataTypes.INTEGER,
      allowNull : false,
      primaryKey : true,
      autoIncrement : true,
    },
    text : {
      type : DataTypes.STRING(140),
      allowNull : false,
    },
    img : {
      type : DataTypes.STRING(200),
      allowNull : false,
    },
  }, {
    timestamps : true, // true -> createdAt, updatedAt column생성
    paranoid : true, // true -> deletedAt column생성(실제로안지워짐)
  })
};
