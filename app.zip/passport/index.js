const kakao = require('./kakaoStrategy');
const { User } = require('../models');

module.exports = passport => {
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id, done) => {
    try {
      const user = await User.findOne({ where : { id } });
      if (user) {
        done(null, user.id);
      }
    } catch (error) {
      done(error);
    }
  });

  kakao(passport);
};
