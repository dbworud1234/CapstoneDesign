const express = require('express');
const router = express.Router();
const db = require('./mysql');

router.get('/', function(req, res, next){
  res.render('capstone/firstPage');
});

router.get('/main', function(req, res, next){
  console.log('///////////////');
  var user_number = req.user;
  var name = '';
  db.query('select nickname from users where id = ?', user_number, function(error, results, fields){
    if(error) {
      console.log(error);
    } else {
      name = results[0].nickname;
      console.log(req.session);
      res.render('capstone/main', { user : name });
    }
  });
});

router.post('/main', function(req, res, next){
  res.render('capstone/searchResultPage');
  console.log('////////////');
});

router.get('/logout', function(req, res, next){
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
