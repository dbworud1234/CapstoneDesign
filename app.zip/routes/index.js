const express = require('express');
const router = express.Router();
const db = require('./mysql');
const { Board, User } = require('../models');

router.get('/', function(req, res, next){
  res.render('capstone/firstPage');
});

router.get('/main', function(req, res, next){
  var user_number = req.user;
  User.findOne({ where : { id : user_number } })
  .then((user) => {
    // Board.count().then(c => {
    //   db.query('select img from boards', function(error, results){
    //     if (error){
    //       console.log(error);
    //     } else {
    //       var image = results;
    //       console.log(image[0].img);
    //       console.log(image[1].img);
    //       res.render('capstone/main', { user : user.nickname, count : c, img : image })
    //     }
    //   })
    //
    // })
    Board.findAll({
      order : [['createdAt', 'DESC']],
    }).then((boards) => {
      console.log('boards : ', boards);
      res.render('capstone/main', {
        user : user,
        boards : boards,
      });
    })
  })
});

router.post('/main', function(req, res, next){
  res.render('capstone/searchResultPage');
  console.log('////////////');
});

router.get('/logout', function(req, res, next){
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
