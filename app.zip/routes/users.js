var express = require('express');
var router = express.Router();
var db = require('./mysql');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.render('capstone/name');
});

router.post('/name_create', function(req, res, next) {
  var body = req.body.name;  // 이름 친대로 나온다.
  db.query('INSERT INTO `member` (name) VALUES (?)', body,
  function(error, result){
    if(error) {
      throw error;
    }
    else {
      console.log(result);
    }
  })
  //       res.writeHead(302, {Location: `/main`});
  //     }
  //   )
  // });
  res.writeHead(302, {Location: `/main`});
  res.end('success');
});

module.exports = router;
