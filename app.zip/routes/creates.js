const express = require('express');
const router = express.Router();
const path = require('path');
const multer = require('multer');
const fs = require('fs');

fs.readdir('uploads', function(error) {
  if (error) {
    console.log('uploads 폴더가 없으므로 uploads 폴더를 생성합니다.');
    fs.mkdirSync('uploads');
  }
})

let upload = multer({
  storage : multer.diskStorage({
    destination(req, file, cb){
      cb(null, 'uploads/');
    },
    filename : function(req, file, cb) {
      const ext = path.extname(file.originalname);  // 확장자(ex : .jpg)
      // file.originalnname : 사진 파일 이름
      cb(null, path.basename(file.originalname) + new Date().valueOf() + ext);
    }
  }),
  limits : {filesize : 5 * 1024 * 1024}
  // dest:"uploads/"
})

router.get('/', function(req, res, next){
  res.render('capstone/creates');
});

router.post('/board', upload.single('imgFile'), function(req, res, next){
  res.render('capstone/board');
});

// router.post('/upload', upload.single('imgFile'), function(req, res, next){
//   var body = req.body;
//
//   //  db.query("INSERT INTO sns (description, tag, created, user) VALUES(?, ?, NOW(), ?)", [body.description, body.tags, ])
// });

module.exports = router;
